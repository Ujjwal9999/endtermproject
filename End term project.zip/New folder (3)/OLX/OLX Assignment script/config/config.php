<?php

defined('DB_SERVER') ? null : define("DB_SERVER", "localhost");
defined('DB_NAME')   ? null : define("DB_NAME", "olx"); // Name of the database
defined('DB_USER')   ? null : define("DB_USER", "root"); // User with database access
defined('DB_PASS')   ? null : define("DB_PASS", ""); // Password of the user

?>
